package com.example.gateway.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gateway.R
import com.example.gateway.data.source.local.entity.JobEntity

class NearbyJobAdapter(private val listJob: ArrayList<JobEntity>) : RecyclerView.Adapter<NearbyJobAdapter.ViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(data: JobEntity)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvItemName = itemView.findViewById(R.id.tv_item_name) as TextView
        val jobPhoto = itemView.findViewById(R.id.job_photo) as ImageView
        val tvItemAddress = itemView.findViewById(R.id.tv_item_address) as TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.item_job, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (title, photo, address) = listJob[position]
        holder.tvItemName.text = title
        if (photo != null) {
            holder.jobPhoto.setImageResource(photo)
        }
        holder.tvItemAddress.text = address
        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(listJob[holder.adapterPosition])
        }
    }

    override fun getItemCount(): Int = listJob.size
}