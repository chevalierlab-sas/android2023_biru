package com.example.gateway.ui.details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.gateway.R

class DetailJobActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_job)
    }
}