package com.example.gateway.data.source.local.entity

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class JobEntity(
    val title: String?,
    val photo: Int?,
    val address: String?,
    val id_job: Int?,
    val id_user: Int?,
    val id_category: Int?,
    val description: String?,
    val salary: String?
) : Parcelable
