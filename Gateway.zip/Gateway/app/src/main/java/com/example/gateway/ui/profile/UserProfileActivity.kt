package com.example.gateway.ui.profile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.gateway.R

class UserProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)
    }
}