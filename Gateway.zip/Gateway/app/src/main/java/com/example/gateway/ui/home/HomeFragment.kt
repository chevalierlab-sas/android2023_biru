package com.example.gateway.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gateway.R
import com.example.gateway.data.source.local.entity.JobEntity
import com.example.gateway.databinding.FragmentHomeBinding
import com.example.gateway.ui.adapter.NearbyJobAdapter
import com.example.gateway.ui.details.DetailJobActivity
import kotlinx.coroutines.Job

class HomeFragment : Fragment() {

    private lateinit var rvNearbyJob: RecyclerView
    private val list = ArrayList<JobEntity>()

private var _binding: FragmentHomeBinding? = null
  // This property is only valid between onCreateView and
  // onDestroyView.
  private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this)[HomeViewModel::class.java]

        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        rvNearbyJob = binding.rvNearby
        rvNearbyJob.setHasFixedSize(true)
        list.addAll(getListJob())
        showRecyclerList()
        return binding.root
    }

    // Showing dummy data
    private fun getListJob(): ArrayList<JobEntity> {
        val dataTitle = resources.getStringArray(R.array.data_job_name)
        val dataDescription = resources.getStringArray(R.array.data_job_description)
        val dataAddress = resources.getStringArray(R.array.data_job_address)
        val dataSalary = resources.getStringArray(R.array.data_job_salary)

        val listJob = ArrayList<JobEntity>()
        for (position in dataTitle.indices) {
            val job = JobEntity(
                dataTitle[position],
                samplePhoto[position],
                dataAddress[position],

                dataDescription[position],
                dataSalary[position]
            )
            listJob.add(job)
        }

        return listJob
    }

    private fun showRecyclerList() {
        rvNearbyJob.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            val listJobAdapter = NearbyJobAdapter(list)
            this.adapter = listJobAdapter

            listJobAdapter.setOnItemClickCallback(object : NearbyJobAdapter.OnItemClickCallback {
                override fun onItemClicked(data: JobEntity) {
                    val moveIntent = Intent(activity, DetailJobActivity::class.java)
                    moveIntent.putExtra(DetailJobActivity.EXTRA_JOB, data)
                    startActivity(moveIntent)
                }
            })
        }
    }

override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}